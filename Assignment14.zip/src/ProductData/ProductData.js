const productData=[
  {
    "id": 1,
    "name": "Logitech Wireless Mouse",
    "category": "Electronics",
    "description": "Reliable wireless mouse for everyday use.",
    "price": 19.99,
    "image": "https://th.bing.com/th/id/OIP.ngCVSpKTIw1ovsH5YUKX7QHaHa?rs=1&pid=ImgDetMain",
    "rating": 4.5
  },
  {
    "id": 2,
    "name": "Anker Portable Charger",
    "category": "Electronics",
    "description": "Compact and high-speed portable charger for smartphones and tablets.",
    "price": 29.99,
    "image": "https://th.bing.com/th/id/OIP.QHxvoKCQjKgEAHRoV03BdwAAAA?rs=1&pid=ImgDetMain",
    "rating": 4.6
  },
  {
    "id": 3,
    "name": "Amazon Basics Backpack",
    "category": "Fashion",
    "description": "Simple and durable backpack for daily use.",
    "price": 29.99,
    "image": "https://th.bing.com/th/id/OIP.3k68nbbqJuLevrqlYaD4AgHaHa?rs=1&pid=ImgDetMain",
    "rating": 4.3
  },
  {
    "id": 4,
    "name": "JBL Bluetooth Speaker",
    "category": "Electronics",
    "description": "Compact and powerful portable speaker with Bluetooth connectivity.",
    "price": 119.99,
    "image": "https://th.bing.com/th/id/OIP.b7f8TglqCljSAtq-YxADAgHaGk?rs=1&pid=ImgDetMain",
    "rating": 4.8
  },
  {
    "id": 5,
    "name": "Adidas Classic Baseball Cap",
    "category": "Fashion",
    "description": "Stylish and comfortable baseball cap for everyday wear.",
    "price": 24.99,
    "image": "https://th.bing.com/th/id/OIP.FylepyjL0zKKX2R2FtpIagHaHa?rs=1&pid=ImgDetMain",
    "rating": 4.5
  },
  {
    id: 6,
    "name": "Crayola Colored Pencils",
    "category": "Stationery",
    "description": "Vibrant colored pencils for drawing and coloring.",
    "price": 7.99,
    "image": "https://th.bing.com/th/id/R.6f7f4503181a43d4c728d5fef3efec15?rik=zd0r2bLK%2bQRZOQ&pid=ImgRaw&r=0",
    "rating": 4.6,
  },
]
export default productData;

