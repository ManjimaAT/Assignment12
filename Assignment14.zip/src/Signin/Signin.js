import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Link,
} from '@mui/material';
import { authenticateUser } from '../Validation/Validation';
import "./Signin.css"

const Signin = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  })
  const [error, setError] = useState('');
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  const handleLogin = (e) => {
    e.preventDefault();
    const { email, password } = formData;
    const userExists = authenticateUser(email, password);
    if (userExists) {
      alert("Logged in successfully");
      navigate('/dashboard');
    } else {
      setError('User with the provided credentials does not exist.');
    }
  }
  return (
    <Container className="container" component="main" maxWidth="xs">
      <Paper className="paper" elevation={3}>
        <Typography variant="h5" align="center">
          Login
        </Typography>
        <form className="form" onSubmit={handleLogin}>
          <TextField
            className="text-field"
            label="Email"
            variant="outlined"
            margin="normal"
            fullWidth
            required
            name='email'
            value={formData.email}
            onChange={handleChange}
          />
          <TextField
            className="text-field"
            label="Password"
            type="password"
            variant="outlined"
            margin="normal"
            fullWidth
            required
            name='password'
            value={formData.password}
            onChange={handleChange}
          />
          <Button
            variant="contained"
            color="primary"
            fullWidth
            type="submit"
            style={{ marginTop: 20 }}
          >
            Login
          </Button>
        </form>
        {error && <p className="error">{error}</p>}
        <Typography className="link" align="center" style={{ marginTop: 10 }}>
          Don't have an account?{' '}
          <Link href="/register">
            Register Here
          </Link>
        </Typography>
      </Paper>
    </Container>
  );
};


export default Signin;
