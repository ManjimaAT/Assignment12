import React, { useState } from 'react';
import { Card, CardContent, CardActions, Button, IconButton, Typography } from '@mui/material';
import FavoriteIcon from '@mui/icons-material/Favorite';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import ShareIcon from '@mui/icons-material/Share';
import productData from '../ProductData/ProductData';
import './Product.css';

const ProductDetails = (props) => {
  const [showDetails, setShowDetails] = useState(false);
  const [heartFilled, setHeartFilled] = useState(false);

  const toggleDetails = () => {
    setShowDetails(!showDetails);
  };

  const handleHeartClick = () => {
    setHeartFilled(!heartFilled);
  };

  const handleCartClick = () => {
    alert(`Product "${props.name}" added to the shopping cart`);
  };

  const handleShare = () => {
    alert(`Product "${props.name}" link has been shared`);
  };

  return (
    <Card className={`product ${showDetails ? 'show-details' : ''}`}>
      <CardContent>
        <img src={props.image} className="product-image" alt={props.name} />
        <Typography variant="h6" className="product-name">{props.name}</Typography>
        <Typography variant="subtitle2" className="product-category">{props.category}</Typography>
        <Typography variant="body1" className="product-price">${props.price}</Typography>
        <Typography variant="body2" className="product-rating">Rating: {props.rating}/5</Typography>

        <Button className="dropdown-btn" onClick={toggleDetails}>
          {showDetails ? 'Hide Details' : 'Show Details'}
        </Button>

        {showDetails && (
          <div className="dropdown-content">
            <Typography variant="body2" className="product-description">{props.description}</Typography>
          </div>
        )}
      </CardContent>

      <CardActions>
        <IconButton onClick={handleHeartClick} className={`heart-icon ${heartFilled ? 'filled' : ''}`}>
          <FavoriteIcon />
        </IconButton>
        <IconButton onClick={handleCartClick} className="cart-icon">
          <ShoppingCartIcon />
        </IconButton>
        <IconButton onClick={handleShare} className="share-icon">
          <ShareIcon />
        </IconButton>
      </CardActions>
    </Card>
  );
};

const productComponents = productData.map(product => (
  <ProductDetails
    key={product.id}
    name={product.name}
    category={product.category}
    price={product.price}
    description={product.description}
    rating={product.rating}
    image={product.image}
  />
));

export default productComponents;
